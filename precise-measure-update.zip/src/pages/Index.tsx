
import React from 'react';
import UnitConverter from '../components/UnitConverter';

const Index = () => {
  return (
    <div className="bg-appblue min-h-screen">
      <UnitConverter />
    </div>
  );
};

export default Index;
